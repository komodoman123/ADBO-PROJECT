﻿using UnityEngine;
using System.Collections;

public class Over : MonoBehaviour {
	public bool over;
	public Start ob;
	public GUIStyle style1;
	public Texture image1;
	public AudioSource[] audiOver;
	// Use this for initialization
	void Start () {
		over = false;

		Time.timeScale = 0;
		audiOver = GetComponents<AudioSource>();
		
	}
	
	// Update is called once per frame

	void OnTriggerEnter2D(Collider2D collider){
		
		if (collider.name == "Quad") {
			Time.timeScale=0;
			over=true;
			AudioSource audiOver1=audiOver[1];
			audiOver1.Play ();
		}
}
	void OnGUI(){
		if (over) {
			GUI.Label(new Rect(Screen.width*0.3f,Screen.height*0.45f,Screen.width*0.75f,Screen.height*0.25f),"Game Over!",style1);
			if(GUI.Button(new Rect(Screen.width*0.48f,Screen.height*0.55f, 50, 50), image1)){

				Application.LoadLevel("Scene1");
				Time.timeScale=1;
			}
		}
		if (!ob.start) {
			//GUI.Label(new Rect(Screen.width*0.3f,Screen.height*0.45f,Screen.width*0.75f,Screen.height*0.25f),"Press Space!",style1);
			GUI.Label(new Rect(Screen.width*0.3f,Screen.height*0.45f,Screen.width*0.75f,Screen.height*0.25f),"Tap Anywhere!",style1);
		}
	}
}
