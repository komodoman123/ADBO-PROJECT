﻿using UnityEngine;
using System.Collections;

public class CamRunner : MonoBehaviour {

	public Transform Box;
	public GUIStyle style;
	public float sc=0.0f;
	public int sco;
	public int hi;
	public AudioSource audi100;
	// Use this for initialization
	void Start () {
		PlayerPrefs.SetInt ("speed",7);
		hi = PlayerPrefs.GetInt ("hi",0);
		audi100=GetComponent<AudioSource>();
		sco = 0;
	}
	
	// Update is called once per frame
	void Update () {

		//transform.position = new Vector3 (TRex.position.x, 0, -10.35f);
		transform.Translate (Vector3. right *   PlayerPrefs.GetInt ("speed") * Time.deltaTime);
		Box.Translate (Vector3.right* PlayerPrefs.GetInt ("speed")*Time.deltaTime);
		sc += Time.deltaTime*10;

		sco = (int)sc;
		if (hi < sco) {
			PlayerPrefs.SetInt("hi",sco);
			PlayerPrefs.Save();
		}
		if (sco % 100 == 0&&sco!=0) {
			audi100.Play();
		}
	} 
	void OnGUI(){

		string high = hi.ToString ();
		string score = sco.ToString();
		GUI.Label (new Rect(Screen.width*0.8f,Screen.height*0.07f,Screen.width*0.2f,Screen.height*0.05f),score,style);
		GUI.Label (new Rect(Screen.width*0.65f,Screen.height*0.07f,Screen.width*0.2f,Screen.height*0.05f),"HI  "+high,style);
	}
}
