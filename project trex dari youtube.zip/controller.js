﻿#pragma strict
var jumpHeight = 5;
private var falling= false;
var audi: AudioSource[];

function Start () {
audi=GetComponents.<AudioSource>();

}

function Update () {

 transform.Translate (Vector3. right *  PlayerPrefs.GetInt("speed") * Time.deltaTime);

if((Input.GetKeyDown(KeyCode.Space)||(Input.GetTouch(0).phase==TouchPhase.Began)&& falling==false)){
GetComponent.<Rigidbody2D>().velocity.y=jumpHeight;
var audiJump:AudioSource=audi[0];
audiJump.Play();
}
falling=true;
}

function OnCollisionStay2D()
{
falling=false;
}

	
