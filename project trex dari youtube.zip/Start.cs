﻿using UnityEngine;
using System.Collections;

public class Start : MonoBehaviour {
	public bool start;
	// Use this for initialization
	void Awake () {
		start = false;
	}
	
	void Update () {
		if (Input.GetKeyDown (KeyCode.Space)||(Input.GetTouch(0).phase==TouchPhase.Began)) {
			start=true;
			Time.timeScale=1;
			Destroy(this);
		}

	}
}
