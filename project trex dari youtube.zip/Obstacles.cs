﻿using UnityEngine;
using System.Collections;

public class Obstacles : MonoBehaviour {

	public GameObject[] ob;
	public Transform campos;

	// Use this for initialization
	void Start () {
		ObstacleMaker ();


	}
	void Update(){

		transform.Translate (Vector3. right *   PlayerPrefs.GetInt ("speed") * Time.deltaTime);
		GameObject cs = GameObject.Find ("Quad");
		if (campos.position.x-cs.transform.position.x>25) {
			Destroy(cs);
		}


	}
	
	void ObstacleMaker(){

		GameObject clone=(GameObject)Instantiate (ob [Random.Range (0, ob.Length)], transform.position, Quaternion.identity);
		clone.name="Quad";
		clone.AddComponent <BoxCollider2D>();

		clone.GetComponent<BoxCollider2D>().isTrigger = true;
		float xx = Random.Range (1, 5);
		//Debug.Log (xx);
		Invoke ("ObstacleMaker", xx);

	}

}
